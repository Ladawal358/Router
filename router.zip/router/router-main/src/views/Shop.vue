<template>
  <v-container>
    <h1>Shop Page</h1>

    <v-container class="d-flex flex-wrap">
      <v-card
        class="mx-auto mb-5"
        max-width="344"
        v-for="(product, index) in productList"
        :key="index"
      >
        <v-img :src="product.image" height="200px" contain></v-img>

        <v-card-title> {{ product.id }}.{{ product.title }} </v-card-title>

        <v-card-subtitle
          >{{ product.price }} $ <v-spacer></v-spacer>
          <v-rating
            :value="product.rating.rate"
            color="amber"
            dense
            half-increments
            readonly
            size="14"
          ></v-rating>
          <div class="grey--text ms-4">{{ product.rating.count }}</div>
        </v-card-subtitle>
        <v-card-actions>
          <v-btn
            color="orange"
            class="btn btn-success"
            @click="addCart(product)"
          >
            Get
          </v-btn>

          <v-btn
            color="blue"
            text
            :to="{
              name: 'detail',
              params: { id: product.id, description: product.description, image: product.image, price: product.price, title: product.title, category: product.category},
            }"
          >
            Detail
          </v-btn>

          <v-btn icon @click="show = !show">
            <v-icon>{{ show ? "mdi-chevron-up" : "mdi-chevron-down" }}</v-icon>
          </v-btn>
        </v-card-actions>

        <v-spacer></v-spacer>

        <v-expand-transition>
          <div v-show="show">
            <v-divider></v-divider>

            <v-card-text> category : {{ product.category }} </v-card-text>
          </div>
        </v-expand-transition>
      </v-card>
      <v-container>
        <v-card>
          <div class="container col-md-12" v-if="carts != 0">
            <h4>Product</h4>
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">Image</th>
                  <th scope="col">Name</th>
                  <th scope="col">Price</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Total</th>
                  <th scope="col">Delete</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in carts" :key="index">
                  <td>{{ item.id }}</td>
                  <td><img :src="item.image" height="50px" width="50px" /></td>
                  <td>{{ item.name }}</td>
                  <td>{{ item.price }}</td>
                  <td>
                    <i class="fa fa-plus qty-plus" @click="plusqty(item)"></i>
                    {{ item.qty }}
                  </td>
                  <td>{{ item.total }}</td>
                  <td>
                    <v-btn
                      class="mx-2"
                      fab
                      dark
                      small
                      color="red"
                      @click="deleteTodo(i)"
                    >
                      <v-icon dark>mdi-minus</v-icon>
                    </v-btn>
                  </td>
                </tr>
              </tbody>
            </table>

            <v-card-footer>
              <center>
                <h3>Total : {{ total() }} $</h3>
              </center>
            </v-card-footer>
          </div>
        </v-card>
      </v-container>
      <v-container grid-list-xs class="green accent-2">
        <router-view :key="$route.path"></router-view>
      </v-container>
    </v-container>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      carts: [],
      prod1: 0,
      prod2: 0,
      prod3: 0,
      prod4: 0,
      prod5: 0,
      prod6: 0,
      prod7: 0,
      prod8: 0,
      prod9: 0,
      prod10: 0,
      prod11: 0,
      prod12: 0,
      prod13: 0,
      prod14: 0,
      prod15: 0,
      prod16: 0,
      prod17: 0,
      prod18: 0,
      prod19: 0,
      prod20: 0,
      prod21: 0,
      show: false,
      productList: [
        {
          id: 1,
          title: "Fjallraven - Foldsack No. 1 Backpack, Fits 15 Laptops",
          price: 110,
          description:
            "Your perfect pack for everyday use and walks in the forest. Stash your laptop (up to 15 inches) in the padded sleeve, your everyday",
          category: "men's clothing",
          image: "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg",

          rating: {
            rate: 3.9,
            count: 120,
          },
          active: false,
        },

        {
          id: 2,
          title: "Mens Casual Premium Slim Fit T-Shirts ",
          price: 23,
          description:
            "Slim-fitting style, contrast raglan long sleeve, three-button henley placket, light weight & soft fabric for breathable and comfortable wearing. And Solid stitched shirts with round neck made for durability and a great fit for casual fashion wear and diehard baseball fans. The Henley style round neckline includes a three-button placket.",
          category: "men's clothing",
          image:
            "https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg",

          rating: {
            rate: 4.1,
            count: 259,
          },
          active: false,
        },

        {
          id: 3,
          title: "Mens Cotton Jacket",
          price: 56,
          description:
            "great outerwear jackets for Spring/Autumn/Winter, suitable for many occasions, such as working, hiking, camping, mountain/rock climbing, cycling, traveling or other outdoors. Good gift choice for you or your family member. A warm hearted love to Father, husband or son in this thanksgiving or Christmas Day.",
          category: "men's clothing",
          image: "https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_.jpg",

          rating: {
            rate: 4.7,
            count: 500,
          },
          active: false,
        },

        {
          id: 4,
          title: "Mens Casual Slim Fit",
          price: 16,
          description:
            "The color could be slightly different between on the screen and in practice. / Please note that body builds vary by person, therefore, detailed size information should be reviewed below on the product description.",
          category: "men's clothing",
          image: "https://fakestoreapi.com/img/71YXzeOuslL._AC_UY879_.jpg",

          rating: {
            rate: 2.1,
            count: 430,
          },
          active: false,
        },

        {
          id: 5,
          title:
            "John Hardy Women's Legends Naga Gold & Silver Dragon Station Chain Bracelet",
          price: 695,
          description:
            "From our Legends Collection, the Naga was inspired by the mythical water dragon that protects the ocean's pearl. Wear facing inward to be bestowed with love and abundance, or outward for protection.",
          category: "jewelery",
          image:
            "https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg",

          rating: {
            rate: 4.6,
            count: 400,
          },
          active: false,
        },

        {
          id: 6,
          title: "Solid Gold Petite Micropave ",
          price: 168,
          description:
            "Satisfaction Guaranteed. Return or exchange any order within 30 days.Designed and sold by Hafeez Center in the United States. Satisfaction Guaranteed. Return or exchange any order within 30 days.",
          category: "jewelery",
          image:
            "https://fakestoreapi.com/img/61sbMiUnoGL._AC_UL640_QL65_ML3_.jpg",

          rating: {
            rate: 3.9,
            count: 70,
          },
          active: false,
        },

        {
          id: 7,
          title: "White Gold Plated Princess",
          price: 10,
          description:
            "Classic Created Wedding Engagement Solitaire Diamond Promise Ring for Her. Gifts to spoil your love more for Engagement, Wedding, Anniversary, Valentine's Day...",
          category: "jewelery",
          image:
            "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg",

          rating: {
            rate: 3,
            count: 400,
          },
          active: false,
        },

        {
          id: 8,
          title: "Pierced Owl Rose Gold Plated Stainless Steel Double",
          price: 11,
          description:
            "Rose Gold Plated Double Flared Tunnel Plug Earrings. Made of 316L Stainless Steel",
          category: "jewelery",
          image:
            "https://fakestoreapi.com/img/51UDEzMJVpL._AC_UL640_QL65_ML3_.jpg",

          rating: {
            rate: 1.9,
            count: 100,
          },
          active: false,
        },

        {
          id: 9,
          title: "WD 2TB Elements Portable External Hard Drive - USB 3.0 ",
          price: 64,
          description:
            "USB 3.0 and USB 2.0 Compatibility Fast data transfers Improve PC Performance High Capacity; Compatibility Formatted NTFS for Windows 10, Windows 8.1, Windows 7; Reformatting may be required for other operating systems; Compatibility may vary depending on user’s hardware configuration and operating system",
          category: "electronics",
          image: "https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_.jpg",

          rating: {
            rate: 3.3,
            count: 203,
          },
          active: false,
        },

        {
          id: 10,
          title: "SanDisk SSD PLUS 1TB Internal SSD - SATA III 6 Gb/s",
          price: 109,
          description:
            "Easy upgrade for faster boot up, shutdown, application load and response (As compared to 5400 RPM SATA 2.5” hard drive; Based on published specifications and internal benchmarking tests using PCMark vantage scores) Boosts burst write performance, making it ideal for typical PC workloads The perfect balance of performance and reliability Read/write speeds of up to 535MB/s/450MB/s (Based on internal testing; Performance may vary depending upon drive capacity, host device, OS and application.)",
          category: "electronics",
          image: "https://fakestoreapi.com/img/61U7T1koQqL._AC_SX679_.jpg",

          rating: {
            rate: 2.9,
            count: 470,
          },
          active: false,
        },

        {
          id: 11,
          title:
            "Silicon Power 256GB SSD 3D NAND A55 SLC Cache Performance Boost SATA III 2.5",
          price: 109,
          description:
            "3D NAND flash are applied to deliver high transfer speeds Remarkable transfer speeds that enable faster bootup and improved overall system performance. The advanced SLC Cache Technology allows performance boost and longer lifespan 7mm slim design suitable for Ultrabooks and Ultra-slim notebooks. Supports TRIM command, Garbage Collection technology, RAID, and ECC (Error Checking & Correction) to provide the optimized performance and enhanced reliability.",
          category: "electronics",
          image: "https://fakestoreapi.com/img/71kWymZ+c+L._AC_SX679_.jpg",

          rating: {
            rate: 4.8,
            count: 319,
          },
          active: false,
        },

        {
          id: 12,
          title:
            "WD 4TB Gaming Drive Works with Playstation 4 Portable External Hard Drive",
          price: 114,
          description:
            "Expand your PS4 gaming experience, Play anywhere Fast and easy, setup Sleek design with high capacity, 3-year manufacturer's limited warranty",
          category: "electronics",
          image: "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",

          rating: {
            rate: 4.8,
            count: 400,
          },
          active: false,
        },

        {
          id: 13,
          title:
            "Acer SB220Q bi 21.5 inches Full HD (1920 x 1080) IPS Ultra-Thin",
          price: 599,
          description:
            "21. 5 inches Full HD (1920 x 1080) widescreen IPS display And Radeon free Sync technology. No compatibility for VESA Mount Refresh Rate: 75Hz - Using HDMI port Zero-frame design | ultra-thin | 4ms response time | IPS panel Aspect ratio - 16: 9. Color Supported - 16. 7 million colors. Brightness - 250 nit Tilt angle -5 degree to 15 degree. Horizontal viewing angle-178 degree. Vertical viewing angle-178 degree 75 hertz",
          category: "electronics",
          image: "https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg",

          rating: {
            rate: 2.9,
            count: 250,
          },
          active: false,
        },

        {
          id: 14,
          title:
            "Samsung 49-Inch CHG90 144Hz Curved Gaming Monitor (LC49HG90DMNXZA) – Super Ultrawide Screen QLED ",
          price: 1000,
          description:
            "49 INCH SUPER ULTRAWIDE 32:9 CURVED GAMING MONITOR with dual 27 inch screen side by side QUANTUM DOT (QLED) TECHNOLOGY, HDR support and factory calibration provides stunningly realistic and accurate color and contrast 144HZ HIGH REFRESH RATE and 1ms ultra fast response time work to eliminate motion blur, ghosting, and reduce input lag",
          category: "electronics",
          image: "https://fakestoreapi.com/img/81Zt42ioCgL._AC_SX679_.jpg",

          rating: {
            rate: 2.2,
            count: 140,
          },
          active: false,
        },

        {
          id: 15,
          title: "BIYLACLESEN Women's 3-in-1 Snowboard Jacket Winter Coats",
          price: 57,
          description:
            "Note:The Jackets is US standard size, Please choose size as your usual wear Material: 100% Polyester; Detachable Liner Fabric: Warm Fleece. Detachable Functional Liner: Skin Friendly, Lightweigt and Warm.Stand Collar Liner jacket, keep you warm in cold weather. Zippered Pockets: 2 Zippered Hand Pockets, 2 Zippered Pockets on Chest (enough to keep cards or keys)and 1 Hidden Pocket Inside.Zippered Hand Pockets and Hidden Pocket keep your things secure. Humanized Design: Adjustable and Detachable Hood and Adjustable cuff to prevent the wind and water,for a comfortable fit. 3 in 1 Detachable Design provide more convenience, you can separate the coat and inner as needed, or wear it together. It is suitable for different season and help you adapt to different climates",
          category: "women's clothing",
          image: "https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_.jpg",

          rating: {
            rate: 2.6,
            count: 235,
          },
          active: false,
        },

        {
          id: 16,
          title:
            "Lock and Love Women's Removable Hooded Faux Leather Moto Biker Jacket",
          price: 30,
          description:
            "100% POLYURETHANE(shell) 100% POLYESTER(lining) 75% POLYESTER 25% COTTON (SWEATER), Faux leather material for style and comfort / 2 pockets of front, 2-For-One Hooded denim style faux leather jacket, Button detail on waist / Detail stitching at sides, HAND WASH ONLY / DO NOT BLEACH / LINE DRY / DO NOT IRON",
          category: "women's clothing",
          image: "https://fakestoreapi.com/img/81XH0e8fefL._AC_UY879_.jpg",

          rating: {
            rate: 2.9,
            count: 340,
          },
          active: false,
        },

        {
          id: 17,
          title: "Rain Jacket Women Windbreaker Striped Climbing Raincoats",
          price: 40,
          description:
            "Lightweight perfet for trip or casual wear---Long sleeve with hooded, adjustable drawstring waist design. Button and zipper front closure raincoat, fully stripes Lined and The Raincoat has 2 side pockets are a good size to hold all kinds of things, it covers the hips, and the hood is generous but doesn't overdo it.Attached Cotton Lined Hood with Adjustable Drawstrings give it a real styled look.",
          category: "women's clothing",
          image: "https://fakestoreapi.com/img/71HblAHs5xL._AC_UY879_-2.jpg",

          rating: {
            rate: 3.8,
            count: 679,
          },
          active: false,
        },

        {
          id: 18,
          title: "MBJ Women's Solid Short Sleeve Boat Neck V ",
          price: 10,
          description:
            "95% RAYON 5% SPANDEX, Made in USA or Imported, Do Not Bleach, Lightweight fabric with great stretch for comfort, Ribbed on sleeves and neckline / Double stitching on bottom hem",
          category: "women's clothing",
          image: "https://fakestoreapi.com/img/71z3kpMAYsL._AC_UY879_.jpg",

          rating: {
            rate: 4.7,
            count: 130,
          },
          active: false,
        },

        {
          id: 19,
          title: "Opna Women's Short Sleeve Moisture",
          price: 8,
          description:
            "100% Polyester, Machine wash, 100% cationic polyester interlock, Machine Wash & Pre Shrunk for a Great Fit, Lightweight, roomy and highly breathable with moisture wicking fabric which helps to keep moisture away, Soft Lightweight Fabric with comfortable V-neck collar and a slimmer fit, delivers a sleek, more feminine silhouette and Added Comfort",
          category: "women's clothing",
          image: "https://fakestoreapi.com/img/51eg55uWmdL._AC_UX679_.jpg",

          rating: {
            rate: 4.5,
            count: 146,
          },
          active: false,
        },

        {
          id: 20,
          title: "DANVOUY Womens T Shirt Casual Cotton Short",
          price: 13,
          description:
            "95%Cotton,5%Spandex, Features: Casual, Short Sleeve, Letter Print,V-Neck,Fashion Tees, The fabric is soft and has some stretch., Occasion: Casual/Office/Beach/School/Home/Street. Season: Spring,Summer,Autumn,Winter.",
          category: "women's clothing",
          image: "https://fakestoreapi.com/img/61pHAEJ4NML._AC_UX679_.jpg",

          rating: {
            rate: 3.6,
            count: 145,
          },
          active: false,
        },
        {
          id: 21,
          title: "My item is Poy-Sian",
          price: 9.99,
          description: "Relief of nasal congestion",
          category: "Inhaler",
          image:
            "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRgWFRYYFRgYHBkYHBgZGhgYGBgaGBgZGhoYGBkdIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHjQrJSs0NDQ0NDY0NDQ0MTQ0NDQ0NjQ0NDQ0NDQ0NDQ2NDQxNDQ0NDQ0NDQ0NDQ0NDQ0NDY2NP/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EAD4QAAIBAgQDBQYEBQMDBQAAAAECAAMRBBIhMQVBUQZhcYGRExQiMqGxQlLR4TNicsHwB4KSI0PCFpOisvH/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAAnEQACAgICAgICAQUAAAAAAAAAAQIRAyESMQRRMkEigWETccHR8P/aAAwDAQACEQMRAD8A9mhCEACEIQAzOPfwT4j7yxw3+En9K/aQcd/gt4j7ybhf8Gn/AEj7SF8n/Y0fw/ZchCEszCEIQAIQhAAhCEACEIQAzeM/JLmH+Vf6R9pT418nrL1PYeA+0zXyZpL4L9kkIQmhmJIcWfgbwk0r475G8vuIn0NdmKYkdaIRrMDpG2g0UiEQDbQgTFEACEWEYjo4TCxfHEQ2dgvfex8hIB2iQMFDZg2zbgnpfrNnJIwcGjUxP8elqbFalxcgG2S1xsbXMq8NqMHVKly/syQyuXp1VUqC9vwt8Sm1rWewLW0fhnUsHJZj8VrkELnykhdNvhG5NtZfoYdEAyqFAAUACwC8lUch3CaclRLTTK3HP4LeX3k3Cv4Sf0iRccP/AEW8vuJJwn+Cn9ImS+f6NH8P2XYQhLMwhCEACEIQAIQhAAhCEAMvjXyev9ppLMzjR+Ef5zmoJnH5P9Gkviv2LCEJoZiSrxA/AfL7y1KfEvk8xJfTHHtGUDEbcRQYjTA6QaJFMSACCLCEAC8JFmMWFhR51xDheMZ/aMA5OvwsCV/lsYYLiTC45c1bb9jO0w+CVdba/iPfecf2i9mMQwXNfKNANM3InvlvezPLjUdpnRcPxLFPaLfItwRfbTmOc36FatYNnYNa9iSV12FjptOU4PiFpULuCS7hFXqTYa906vDOSNbAxrqxJJpciXGcRL0aiMuVlCnuYE7jp4TT4If+hT8JRxGCPwliCupYX32yrbmOfkZEK7Br31/z6RxTuylHlGl7OihKWGxoYG+4FyBzA5iRvjzewE0Rk4tOjRhM0Y1ovvxgHFmjCZwxxi+/GAcWaEJn+/GKMdAOLL8JSGNi++wFTK/Gdh5feaYmfWqI3zC9u8jaTe+CRGLUm/ZUnaS9FuEre+LJUe+ttJZNEkpcU+UeP9jLl5UxqhgATax33iabQLsyrRpls4Zfz/T9404QfnHpMeEvRvyRXESWvdf5h9Y04U/mX6/pDhL0HJFe8RpOMIeq+v7QbCt1X1hxl6HyRVywln3Vu71hFxl6HyRnYu5U2bL4dZztPhFwwzam5zEXNzzvedO6Sni6bKLouYcwDZvEdYStKyeyvgeBu1MotTRbWBUW3vvy15zpeD03CZK1MBlNsxAKsttDfrylTBOy0qjW1CFrHuBMudmuLDFYdK1gCbhl3yspsR/fwImsF+KZjLuibihUKBoN+6YrV16y5xohmA6aTMCAGc2TyXGTSR24YVFFijXFxa/9teR6ialGqSNLL4ben7zJFRV1NhHvjQo1v5TJ523bKljv6NFsxNmKkeeYeGkh9g19LHwK/rKCYy/dJDjI4+RRDwsunDVPyn1H6xvsWGpIH1P0hSx+YWBsR/l5FVqTtj+StMhY3ewZ++/LzHIjkY01Y/DoHBBJHQj/ADvMhxFJk31B2I2P6RcqdCcUmSCpF9pH4VsqAru17nnYG1vpJHKt8w16jQ/v5y0tEOLIRUh7SR16ZXfUHY8v2PdI88Aou4Q5mUHa/wC82Hec9h6uVlbkCLzeKk7D1jTM5LYt5GzecVkI1JHgBKGIxhB+Hb1v4yrCMHLoixIynTY7d3dIvbSz7H2y3VgpB1BHPx85Ur8Pqr+HMOq6/Tf6SWP+GHt4e8SiXie0hY6ND3gxPeZQ9pENSFiND3k9YTO9rCFgRPxVbkdDbzhQ4lckHvtMyphWy8ieV+V9zJ6OHuDY2JFvPmZbxox/qM6LhGKVw673Qg9DprMzsfgnwwxNyBSdwaa7m+X42v0+Vf8AZJ+z1LK5FzqCNdtuUsYtgiKi3soCi+p05k8zOfPNQjo3wQ5y2QYivcys1WV2c98jeprPHlOz1oxIOJnO9FDqC+dvCmL2PiSolX3oZnxBuxY+ypqD82U208XvryAMfiwwYuupCMidSzsvoBlGsiw1GzKPwUhkW/4nI+J/T6sZqpJRIcbkaeGZ1QB3ztuxAAFzyFht46yQV5ULxpeY8rdmnHRbGIINwbGXKOPV9Do3Tr4TGLxqrczbFnlDroUsaZ2OC2P26jnJ2IIsdQdxMPh+IKgak2Ol++a5fmNj/hmzzqUrRzSg12NtlAAOw/eOQHkJP7IWB5kX/SSIJ6ULcU2cs8laRJhqenxWIO4Ot/WSCnTGoRfQTP4rxNMPSaq+YqtrhQCxuQosCQNyOcr1uMKMQmHyuXdDUuMuVFF/m1vuLaA7iW0jF29mwa/TTwjhiJj4DiSVS4Qk+zcoxsQMw3APPeWi8NEj8XVJmY73l1mkbC/KDRvHLSqg4XUsxXqPqP2vNbOZjKgVgw0I6TSSrm8YIzk03aGYvCU6nzCzfmG/n185zmLw7U2yt5HkR3TpS0hxNFXQq3keh6xONiUqOZzRC0bUUqxVtCDYxt5BY/NCMvCAGW/HLDZYLx3oF9Y1OAUz85bfkfrHns9QA/H/AMjMXmfszXiyqzX7PY41HLaWVSbDw0+pk2JxAbUHmR4HmCOR7pB2aw1NEqezvcgg3NzcESKu+rfFmtYXsB10uND4cr985PJlyR3eLDiqZ512m7RYlcW+So6LRcoiKSEIQ2+NBo2Yi+vIz0GudTpbXbp3TLq8CovWXEuDnQqbAjIzL8jOCLkiw2IvlF787Zec+WcZRioqqWzo8fFKMm5MVmhmkRJ57HbW8S+oHUgesxlGUXTVHW1QrPANPO+JdqMS1RjTqNSQEhVQ5dAbAv8AmY769dNJ3fCsaa+GpVnADtcNYWDFWZSw8ct/ObZfHliipP7OTH5MZz4pFq8ehkN4oeYo6WjQoPabvD2zADw9Of0vOWWrNzgFW+Y9LD1//PrNsEbmkY5tQbOhZrmKDIQ8UPPcR5DRi9thfCuP5qd//cSZuJxYTF4yuf8AsYemo/33cD1Ues3uM4X21F6YIUuLAnYEEEH1AmVj+BtUNa7Llr1aLuDf+FSCXTbUkq3k0H3YJ6pljsrgzSw1NW+dhne++d/iN+8Agf7Zr3jTEvGtIlu3Y6ITC8QmMAJio9owxC0QF1nvrGZpFTbQwLQAz+N0LgVBy0b+x/t6TIzTpCAwKnYix85zDgqSp3BI9JMioj80SR5oSSirg8SXDC/dfv5WlmlVKp8bAnW52lzD9mKiOSHVgeRBGskrdnKjnUpbvvOaWOV9GsZpR29jeDoEsE1DElrnk25vDE0stxa1unnNPBcBZQMz3t+UW8tYvGcDlUMNtj3HleRlwtxsrDlSlRz5blK7Sw0hqb6zzpRZ6UJFV2kZMSo2pjbyNvs1MfE9ksPUcvnemGJZkUKRc6nIx+QE8iGt4aTduqqtOmMqIAqr0A7zueZPMkyLNIq1QhSQL+G9uZHUgcucuU5zpSd10c6wwg3KKJUrg3AINt7EG1opeUF1AJC1Vto2Vc1vDY+VvCTZgBYaDeVKKXRSk2WQ83uyz3ps3V2+gUf2M5CviLAzX7KYxThmzVfZZajfF8P4rEAhgQb5vHpOrxI/lZh5Mvxo3+0/EWoYapUUAsqkqDqM2y3HMAm/lOJ/067T4h8SaNaoai1FZgWtdXUZtLAaEBtO4TtnoricOUc5wwZScj0w17qfhb4gCDv5jlMDsh2LOFrtWZ89lKILAWDHVjYm5sLctz1066Sm21t9Ojz31o7omJeNzTD4XxCu9ZkddBe4tbJbbXmD9dxOoI4nKLa+tm8TPNO1P+oNSnWalh0UhDlZnzEFhuqhSNtrk7g6aXPpDTxvtd2TxCYl3p0zUSoxcFbXBc3YEb7km+1jMsjVq3S/yZq/o9C7H9pBi6eYjK6nIy3uA1rgg81I68wROjJnDf6fcEqUKZL6M7B2ANwuVbKlxox3JtoL2nW4rHpTtnJGa9gFdybWvooJ5iRgd3u1en/A5Lr2WiY0mUKPFUcgItXXmaNVF82dABLd5vZNEytDPIWa0YXjGWA05/ielVu+x9QJuK05/itS9U9wA+n7yWOJDmhIs0SSUeh+9J1iHGIOpmTTpknT6y2mGA+Y38NpPMOBdXGqdFUnwk+XOpVgLEWIvc/TaQKQqmwtpMPFIGN9Q3JwSrjwcaiUtrY1C+inx3hL0bst2Q/i5r3N+sw6zX1El4j2pxdO+HLIx1y1WC5nU6ZSD8OYagm2oI75nU6OJYX9nfvDoPVc36Tjy4E3pM6sWWUV+TQlVtY28pcRqshsym/O3xettpTPF1G5PmCPuJzS8aXo6F5Ea7NfNGO9pQwb1a5tQQv1bTKPFthNLG9msSqFhUR2AvkAIueimEfEm9jfkR+ioHAvbmb25X5nxMgq4iYbcRsSHOUjQg7gjlKmK4sDoD5zSPjyb2ZyzxS0XuIY/kJo9g+MCnXNNjYVbWPIOt7DzBI8hOWCO+osQed45ME1wcwW2oIvcEcx0nXDHw6OSeRzPcsCHGZnbMzG9gfhQDRVXy3PMk8rAWw85Hszx/2ihHPxgb7Z7cx39ROlSpN0Ysuq0fKgqR/tR1lATkxDaQe1h7SAiUmYfGq7K4zPWopb+LTKMim4P/VRlbKunzWtvcjS+qzyNqkBIgwy1LgmstRCLg+zs56HOr5SP9ssZ5VoZEBVFCgkmyiwud7DYdYlbEgc4WFFipVkaPczNOLuYNjQo3EVhRr1MQFFydBrOZrVs7FupvG4vHF9Bt9/2kCtBjRYzQkWaERVnpFRDOf4h2nw9HQN7R/ypYi/e2w+p7pyHFOM16+lRzlOyL8KeBHPzvM/C4N6hyombv2UeJ28pyt+joUfZ2nBO1L13qipkRFQMqi5PzAEsx33HSU+JdrKaXCIzn/iPrr9I3h3B/YUars+YsFXKB8IIN73Opt/eZWGwOZszDbYTrxRuNsxnPjKokdbG18QLOAib5QPuTz9JWxeKZF0J6KLm3jbyP8Ahmhi2IZEFhfMWPcoHpqRMHEOzZW3LE5RyC7D6D7Sm0iNy2V/eXH429b/AEMkoYkMQrhVuQC9r5RfVrXsbbyF0AgtOOibPVsBhUp01RAAoHLnfdj1J3hX2nn3C+NV6NkVsyDZG1A8DuB5zbXtUpFnQqeqm4+touJ0Ryxqjg+1uEVcU+X8WVj4ka/r5zFahOl4qgqu9QG9z4aW0EyzRio55dmdRcodJpJVBF5Ur05DnIVvC0lxBSokPF3VrpYWNx18bzseB9uwbJX+E7Zx8p8ek89IgJVC5M9yw/FkYXDAg98n99Xe88PpYh1Fldh4GW04xiB/3CfG36RUPke0LjF6xHx6jmJ45/6gxP5/pK2J4xXdSrObHoSLwofJHpfFe2+HpErmLsPwpr6nYesyMP8A6hIzBWRkU6ZiQQP6rHSeb3gIE2etY7tTRpj4nF/yjVv+I1mHW7b02NrOB1sLDxAN/pOBtEhQcj0zD8SzrmVgVPMf5pJVcnc3nnfDOIPRa66qfmXkf0PfO7wuIV1Dqbgi4/fviGnZfQyVWlZGkoeMZPeEhzQgM08NwZRq/wAZ6fh9Oc2adPQBbDuAsB4SP2nQGXaCai4sN7TmUbZ0N0RcYslNU5n4m8Ty+0xqWg+ssdo8aqhqjtlRLXNrm50VVXmxO22xN9JlUuJI9NXpk5XB+YWYEEggjqCDOqMlfFfRyu3tlLij6sR+TKPF2sP/AKzILXJI2UZF8BuR9vWaOOxBPPQcpmtKrdj5aoayRNZaw+GZ/kUtbe2w8TsImKoMhs6FT3j7dYucbq1fr7Jp9lcCJEdu6LeUIjp6Meh0P6yviUynxlhV1JkeOOn+cogMzECZ9bYzQqtpM7EmSwKoEkUyOLeAEhB3tptfv6RWBBIIsRy6SWlqEHVz/wCEa1XR25uxUHnbdrf/ABEVl0iItGtGXgGjIArG5Y68UQAUJeMZLSUGOIuLQAqzX4FxM0nysfgY6/yn836/tMllsYCAHpiNH55z3ZnHF0KMdUtbvQ7em3pNovJLWyxnhK3tIRDPQEpafWTVGIU5dSBz0+sAJHXQMjAi4IOkyjpo1ltHG9r6b1qDoqsXBSpk3ZsuYMoA3IDk2G9tJncKwj08OiuCrsXfK2jKrEBQRyJylrfzTdS+ZWyhdNF6C/wgjra0pYwkkk6kzaMWpN3p7/Zi3oovh3YFhqF3+8p5e6W3rFQVBsDKy2mgS40uN39mB2mquagpnREVGVeRLoGZ7czclb9FAm/2bqM+AqhzcUnUUyd1uAWQHpqDb+aOqUKTgCtTD5flYFkdRuVDLutyTY31J2vJ61cZFpIi06am4QXNzzZidWPeZzThKTSS6adgmlbsz1UmS5ZGalja6jxJ+mkc5PO3lf8ASdRFEbNKmKfT1+0sOesoYt9ImBWdpm4ltZcZpn1z8RksBl4EzoqS0cNhqdRqSV69cMwFQFqdOmGyiygjMzHny++NxCkoe6CyMquoJvlDDVb88rZlvzyyIzt6X/IbVDKVUAL1XOfMqoX6iNqsPhA2UAeZ1P1NvKQxLyqCxbwvLnDsIHzM7FadMAuQLt8RsqKObMdr6aEnQTW4fgMHiGFJTWoVG0RnZHRm5KwVVKk931O8SnV2CVnPCPBjsXhnpuyOLOrFWHeOndzvIry072hEkcrayMGAMYD642PlIRLD/KfL7ysIAXeF4r2dRX5Xs39J0PpofKdqzTz8Ts8DULUkY7lR9NP7RMqJb9pCVbxZJR6va+0VEJ2177/CPPn4D1Es+wHP05efX7d0VzEo+y3I5niOFyN1HIzHrprOs4hVTKQ2v+cpy2JqLff1miZmZOJp2Og31kYWW8R9vsd/87pWLSrE0IRBliFo1nhYhjIRcg3B3U/+JO3ht4SFwo2Fvp9NpMzyrXqRAQ1GmXiqwvvH4zHBdAbmZTOTra8GxEz1xylci9zY9bjbzimmx5RClt/TqYmBr0aZxNBEVl9rRzKFZlXNTZgQVZiBdTcWvsfC+dxMjPlVgyoqoGHysVHxsp5qXLkHoRKhEQyFGn3r/Y27NfgXBhiM/wAeQrawtcm99fDSZeIpZHZCQcrMtxscpIuPSNp1WU3Vip2upINulxGyinKPFJLf2zT4ZTz0qlJRdyyVFXm+QOrKvVrPmA55TbXSXOz3C6r4hDldFR0dmZSqoqsGNyeemg75gAyzW4hWZcrVajL+VnYj0JkSi9pPslNfZe7U41a2Kq1E1RiAD1yqq3Hccsygh6H0Masle3PN43DDy2lRSikl9aB72RkEb6QvEPdACMRYY/CZXk1TYCRBYwFXuna4elkRE/KoB8QNZR7LcGuwquPhGqKfxH8xHQcuv3618MjfhHoJLKijAvFmx7gn5RCIs9LZpTrueUe7xjSrJMnFUSZh47Bk3nVOl5VqUBADgK+EqIfgYgdNx6GVGesN1B8Lj9Z3tbAg8pRqcNHSFio433qpzT0MY2Kfkh9ROsfh3dIzgB0jsKOQetWOyAeJJ/SVnwtZ/mJ8BoJ2xwI6RPcx0hYUcVT4Q0tpwu3KdV7r3Rpw/dCwo5puH90oY/A3XTcaj9J2D0JnYrCGAUcMRbeJNvH8OJ1tY9f1mTUoMu4gSQwhCIAhCEACAcjTl0iRQIAAkqDmY+jhSd5o0OHk8owM5ELTTwGCW4JGb7ek0sNwqa+G4cByiY0h+BvNikshw+GtL9KnJLGezEJYyQgBtGqDtBnvM1K8kXEQCi6rRWEqrVijEg6QAc6RhSK1QQDQAganI2oiWzEywAomiIxqMvlI0pACgaEjNCaRpxppwAzHw0gfC3mwacaaUBHP1eHg8pRq8FU8p1ZoxjURHYUcTV7PKeUpv2ZHhO/9hGHDx2LieeN2a7zIz2bb8xnojYUdI04QdIWFHny9mz1lilwC07j3QQGEHSFhRy+H4PNKhw4DlNkYeSLSisKKVLC2llKIlhUjgkVlDUSSqsAscogAWhH2hACsI9YQgUSCKm0IQESCPMIQEKsIQgARYQgARIQgAGMMIQAYYhiQgAka0IQEM5wMIQARoQhAYR0IQASSiEIAAjoQgAQhCAH/2Q==",

          rating: {
            rate: 5,
            count: 112,
          },
          active: false,
        },
      ],
    };
  },
  methods: {
    addCart: function (product) {
      if (product.id == 1) {
        this.prod1 += 1;
        if (this.prod1 <= 1) {
          this.pushdata(product);
        } else {
          var aaa = this.findindex(product);
          this.carts[aaa].qty += 1;
          this.carts[aaa].total = this.carts[aaa].qty * this.carts[aaa].price;
        }
      }
      if (product.id == 2) {
        this.prod2 += 1;
        if (this.prod2 <= 1) {
          this.pushdata(product);
        } else {
          var bbb = this.findindex(product);
          this.carts[bbb].qty += 1;
          this.carts[bbb].total = this.carts[bbb].qty * this.carts[bbb].price;
        }
      }
      if (product.id == 3) {
        this.prod3 += 1;
        if (this.prod3 <= 1) {
          this.pushdata(product);
        } else {
          var ccc = this.findindex(product);
          this.carts[ccc].qty += 1;
          this.carts[ccc].total = this.carts[ccc].qty * this.carts[ccc].price;
        }
      }
      if (product.id == 4) {
        this.prod4 += 1;
        if (this.prod4 <= 1) {
          this.pushdata(product);
        } else {
          var ddd = this.findindex(product);
          this.carts[ddd].qty += 1;
          this.carts[ddd].total = this.carts[ddd].qty * this.carts[ddd].price;
        }
      }
      if (product.id == 5) {
        this.ee5 += 1;
        if (this.ee5 <= 1) {
          this.pushdata(product);
        } else {
          var eee = this.findindex(product);
          this.carts[eee].qty += 1;
          this.carts[eee].total = this.carts[eee].qty * this.carts[eee].price;
        }
      }
      if (product.id == 6) {
        this.prod6 += 1;
        if (this.prod6 <= 1) {
          this.pushdata(product);
        } else {
          var fff = this.findindex(product);
          this.carts[fff].qty += 1;
          this.carts[fff].total = this.carts[fff].qty * this.carts[fff].price;
        }
      }
      if (product.id == 7) {
        this.prod7 += 1;
        if (this.prod7 <= 1) {
          this.pushdata(product);
        } else {
          var ggg = this.findindex(product);
          this.carts[ggg].qty += 1;
          this.carts[ggg].total = this.carts[ggg].qty * this.carts[ggg].price;
        }
      }
      if (product.id == 8) {
        this.prod8 += 1;
        if (this.prod8 <= 1) {
          this.pushdata(product);
        } else {
          var hhh = this.findindex(product);
          this.carts[hhh].qty += 1;
          this.carts[hhh].total = this.carts[hhh].qty * this.carts[hhh].price;
        }
      }
      if (product.id == 9) {
        this.prod9 += 1;
        if (this.prod9 <= 1) {
          this.pushdata(product);
        } else {
          var iii = this.findindex(product);
          this.carts[iii].qty += 1;
          this.carts[iii].total = this.carts[iii].qty * this.carts[iii].price;
        }
      }
      if (product.id == 10) {
        this.prod10 += 1;
        if (this.prod10 <= 1) {
          this.pushdata(product);
        } else {
          var jjj = this.findindex(product);
          this.carts[jjj].qty += 1;
          this.carts[jjj].total = this.carts[jjj].qty * this.carts[jjj].price;
        }
      }
      if (product.id == 11) {
        this.prod11 += 1;
        if (this.prod11 <= 1) {
          this.pushdata(product);
        } else {
          var kkk = this.findindex(product);
          this.carts[kkk].qty += 1;
          this.carts[kkk].total = this.carts[kkk].qty * this.carts[kkk].price;
        }
      }
      if (product.id == 12) {
        this.prod12 += 1;
        if (this.prod12 <= 1) {
          this.pushdata(product);
        } else {
          var lll = this.findindex(product);
          this.carts[lll].qty += 1;
          this.carts[lll].total = this.carts[lll].qty * this.carts[lll].price;
        }
      }
      if (product.id == 13) {
        this.prod13 += 1;
        if (this.prod13 <= 1) {
          this.pushdata(product);
        } else {
          var mmm = this.findindex(product);
          this.carts[mmm].qty += 1;
          this.carts[mmm].total = this.carts[mmm].qty * this.carts[mmm].price;
        }
      }
      if (product.id == 14) {
        this.prod14 += 1;
        if (this.prod14 <= 1) {
          this.pushdata(product);
        } else {
          var nnn = this.findindex(product);
          this.carts[nnn].qty += 1;
          this.carts[nnn].total = this.carts[nnn].qty * this.carts[nnn].price;
        }
      }
      if (product.id == 15) {
        this.prod15 += 1;
        if (this.prod15 <= 1) {
          this.pushdata(product);
        } else {
          var ooo = this.findindex(product);
          this.carts[ooo].qty += 1;
          this.carts[ooo].total = this.carts[ooo].qty * this.carts[ooo].price;
        }
      }
      if (product.id == 16) {
        this.prod16 += 1;
        if (this.prod16 <= 1) {
          this.pushdata(product);
        } else {
          var ppp = this.findindex(product);
          this.carts[ppp].qty += 1;
          this.carts[ppp].total = this.carts[ppp].qty * this.carts[ppp].price;
        }
      }
      if (product.id == 17) {
        this.prod17 += 1;
        if (this.prod17 <= 1) {
          this.pushdata(product);
        } else {
          var qqq = this.findindex(product);
          this.carts[qqq].qty += 1;
          this.carts[qqq].total = this.carts[qqq].qty * this.carts[qqq].price;
        }
      }
      if (product.id == 18) {
        this.prod18 += 1;
        if (this.prod18 <= 1) {
          this.pushdata(product);
        } else {
          var rrr = this.findindex(product);
          this.carts[rrr].qty += 1;
          this.carts[rrr].total = this.carts[rrr].qty * this.carts[rrr].price;
        }
      }
      if (product.id == 19) {
        this.prod19 += 1;
        if (this.prod19 <= 1) {
          this.pushdata(product);
        } else {
          var sss = this.findindex(product);
          this.carts[sss].qty += 1;
          this.carts[sss].total = this.carts[sss].qty * this.carts[sss].price;
        }
      }
      if (product.id == 20) {
        this.prod20 += 1;
        if (this.prod20 <= 1) {
          this.pushdata(product);
        } else {
          var ttt = this.findindex(product);
          this.carts[ttt].qty += 1;
          this.carts[ttt].total = this.carts[ttt].qty * this.carts[ttt].price;
        }
      }
      if (product.id == 21) {
        this.prod21 += 1;
        if (this.prod21 <= 1) {
          this.pushdata(product);
        } else {
          var uuu = this.findindex(product);
          this.carts[uuu].qty += 1;
          this.carts[uuu].total = this.carts[uuu].qty * this.carts[uuu].price;
        }
      }
    },
    pushdata(product) {
      this.carts.push({
        id: product.id,
        name: product.title,
        price: product.price,
        image: product.image,
        qty: 1,
        total: product.price,
      });
    },
    findindex: function (product) {
      for (var i = 0; i < this.carts.length; i++) {
        if (this.carts[i].id == product.id) {
          return i;
        }
      }
      return -1;
    },
    deleteTodo(product) {
      this.carts.splice(product, 1);
    },
    total: function () {
      var sum = 0;
      this.carts.forEach(function (product) {
        sum += product.total;
      });
      return sum;
    },
  },
};
</script>

<style >

</style>